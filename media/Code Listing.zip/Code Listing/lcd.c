//******************************************************************************
//  MSP430F449 LCD interface
//
//  Description:
//    Numerical Direct Drive LCD interface
//
//******************************************************************************

#include <msp430x44x.h>
#include "lcd.h"

#define   TC1MS   180     // defines the number of loops in subroutine waitms() to equal 1 millisecond

void wait_ms(int ms);    
void dly1ms(void);

// email questions to: mahm0001@unf.edu
void setupLCD(void) {

    #ifdef LCD_STATIC_4_5
     // Basic Timer
     BTCTL = (BTCTL & 0xA7) | BT_fLCD_DIV256;  // 128 Hz LCD

    // LCD  on static. All LCD pins muxed to LCD
     LCDCTL = LCDON | LCDSON | LCDSTATIC | LCDSG0_7;
    #else
     #ifdef LCD_4MUX_7_5
      // Basic Timer
      BTCTL = (BTCTL & 0xA7) | BT_fLCD_DIV256;  // 128 Hz LCD

      // LCD  on static. All LCD pins muxed to LCD
      LCDCTL = LCDON | LCDSON | LCD4MUX | LCDSG0_7;
      P5SEL = 0xFF;
      P5DIR = 0x1F;
     #else
      #ifdef LCD_4MUX_SOFTBAUGH
       // Basic Timer
       BTCTL = (BTCTL & 0xA7) | BT_fLCD_DIV64;  // 512 Hz LCD

       // LCD  on static. All LCD pins muxed to LCD
       LCDCTL = LCDON | LCDSON | LCD4MUX | LCDSG0_7;
       P5SEL = 0xFF;
       P5DIR = 0x1F;
      #else
       LCDCTL = 0x00;
      #endif
     #endif
    #endif
}

// email questions to: mahm0001@unf.edu
void lcd_all(char on) {
    unsigned char *i;
    unsigned char mask = 0x00;
    if(on) mask = 0xff;

    for(i=(unsigned char *)LCDM1_;i <= (unsigned char *)LCDM20_;i++) *i = mask;
}

// email questions to: mahm0001@unf.edu
char lcd_seg(char segment, char on) {
    unsigned char *pMem;
    unsigned char mask = 0x01;

    #ifdef LCD_STATIC_4_5
     if(segment > S_ARROW) return 1;
     if(segment & 0x01) mask = 0x10;
     pMem = (unsigned char *)(LCDM1_ + (segment>>1));
    #else
     #ifdef LCD_4MUX_7_5
      if(segment > (CHAR_7 | SEG_7B)) return 1;
      mask <<= (segment & 0x07);
      pMem = (char *)(LCDM1_ + (segment>>3));
     #else
      #ifdef LCD_4MUX_SOFTBAUGH
       if(segment > 0xa0) return 1;
       mask <<= (segment & 0x07);
       pMem = (unsigned char *)(LCDM1_ + (segment>>3));
      #endif
     #endif
    #endif

       if(on) {
         *pMem |= mask;
         _NOP();
       }
    else   *pMem &= ~mask;

    return 0;
}

// email questions to: mahm0001@unf.edu
char lcd_seg_toggle(char segment) {
    unsigned char *pMem;
    unsigned char mask = 0x01;

    #ifdef LCD_STATIC_4_5
     if(segment > S_ARROW) return 1;
     if(segment & 0x01) mask = 0x10;
     pMem = (unsigned char *)(LCDM1_ + (segment>>1));
    #else
     #ifdef LCD_4MUX_7_5
      if(segment > (CHAR_7 | SEG_7B)) return 1;
      mask <<= (segment & 0x07);
      pMem = (char *)(LCDM1_ + (segment>>3));
     #else
      #ifdef LCD_4MUX_SOFTBAUGH
       if(segment > 0xa0) return 1;
       mask <<= (segment & 0x07);
       pMem = (unsigned char *)(LCDM1_ + (segment>>3));
      #endif
     #endif
    #endif

    if(*pMem & mask) *pMem &= ~mask;
    else *pMem |= mask;

    return 0;
}

// email questions to: mahm0001@unf.edu
// place increments from LS(0) to MS(4,7,etc.)
char lcd_char(char loc, char value) {
    unsigned char i;
    #ifdef LCD_4MUX_SOFTBAUGH
     unsigned int map;
    #else
     unsigned char map;
    #endif
    unsigned char place = loc;

    #ifdef LCD_STATIC_4_5
     if(place < 4) {
        place = (3-place) * 8;

        if((value >= 'a') && (value <= 'z'))
            value -= ('a' - 'A');
        switch(value & 0x7f) {
            case ' ' : map = 0x00; break;
            case '0' : map = 0x3f; break;
            case '1' : map = 0x06; break;
            case '2' : map = 0x5b; break;
            case '3' : map = 0x4f; break;
            case '4' : map = 0x66; break;
            case '5' : map = 0x6d; break;
            case '6' : map = 0x7d; break;
            case '7' : map = 0x07; break;
            case '8' : map = 0x7f; break;
            case '9' : map = 0x6f; break;
            case 'A' : map = 0x77; break;
            case 'B' : map = 0x7c; break;
            case 'C' : map = 0x39; break;
            case 'D' : map = 0x5e; break;
            case 'E' : map = 0x79; break;
            case 'F' : map = 0x71; break;
            case 'G' : map = 0x6f; break;
            case 'H' : map = 0x76; break;
            case 'I' : map = 0x06; break;
            case 'J' : map = 0x0e; break;
            case 'K' : map = 0x78; break;
            case 'L' : map = 0x38; break;
            case 'M' : map = 0x37; break;
            case 'N' : map = 0x54; break;
            case 'O' : map = 0x3f; break;
            case 'P' : map = 0x75; break;
            case 'Q' : map = 0x61; break;
            case 'R' : map = 0x50; break;
            case 'S' : map = 0x6d; break;
            case 'T' : map = 0x31; break;
            case 'U' : map = 0x1c; break;
            case 'V' : map = 0x3e; break;
            case 'Y' : map = 0x6e; break;
            case 'Z' : map = 0x5b; break;
            default  : return 1;
        }
        // Turn on the DP is specified
        map |= (value & 0x80);
     } else if(place == 4) {
        switch(value & 0x7f) {
            case '0' : lcd_seg(S_4,0); break;
            case '1' : lcd_seg(S_4,1); break;
            default  : return 1;
        }
        lcd_seg(S_DP4,(value & 0x80));
        return 0;
     } else return 1;

     i = 0;
     if(loc == 0) i=1;

     for(; i<8; i++) {
        lcd_seg(place++,map & 0x01);
        map >>= 1;
     }
    #else
     #ifdef LCD_4MUX_7_5
      if(place < 7) {
        place = place<<3;

        switch(value & 0x7f) {
            case '0' : map = 0xb7; break;
            case '1' : map = 0x12; break;
            case '2' : map = 0x8f; break;
            case '3' : map = 0x1f; break;
            case '4' : map = 0x3a; break;
            case '5' : map = 0x3d; break;
            case '6' : map = 0xbd; break;
            case '7' : map = 0x13; break;
            case '8' : map = 0xbf; break;
            case '9' : map = 0x3f; break;
            default  : return 1;
        }
        if(value & 0x80) map |= 0x40;
     } else if(place == 7) {
        switch(value & 0x7f) {
            case '0' :
             lcd_seg(CHAR_7 | SEG_7B,0);
             lcd_seg(CHAR_7 | SEG_7C,0);
             break;
            case '1' :
             lcd_seg(CHAR_7 | SEG_7B,1);
             lcd_seg(CHAR_7 | SEG_7C,1);
             break;
            default  : return 1;
        }
        lcd_seg(CHAR_7 | SEG_ALT,(value & 0x80));
        return 0;
     } else return 1;

     for(i=0; i<8; i++) {
        lcd_seg(place++,map & 0x01);
        map >>= 1;
     }
     #else // #ifdef LCD_4MUX_7_5
      #ifdef LCD_4MUX_SOFTBAUGH
       if(place < 7) {
         place <<= 1;
         place += CHAR_0;
         place <<= 3;

         if((value >= '0') && (value <= '9')){
          switch(value & 0x7f) {
           case ' ' : map = 0x0000; break;
           case '-' : map = 0x0402; break;
           case '0' : map = 0x62f4; break;
           case '1' : map = 0x0060; break;
           case '2' : map = 0x24d2; break;
           case '3' : map = 0x00f2; break;
           case '4' : map = 0x4462; break;
           case '5' : map = 0x44b2; break;
           case '6' : map = 0x64b2; break;
           case '7' : map = 0x0284; break;
           case '8' : map = 0x64f2; break;
           case '9' : map = 0x44f2; break;
            default  : return 1;
          }
        }
        
        if((value >= 'a') && (value <= 'z'))
        {
          switch(value & 0x7f) {
            case 'a' : map = 0x24f2; break;
            case 'b' : map = 0x6411; break;
            case 'c' : map = 0x2412; break;
            case 'd' : map = 0x0272; break;
            case 'e' : map = 0x6490; break;
            case 'f' : map = 0x6480; break;
            case 'g' : map = 0x08f2; break;
            case 'h' : map = 0x6422; break;
            case 'i' : map = 0x0100; break;
            case 'j' : map = 0x0070; break;
            case 'k' : map = 0x010d; break;
            case 'l' : map = 0x0108; break;
            case 'm' : map = 0x2522; break;
            case 'n' : map = 0x2401; break;
            case 'o' : map = 0x2432; break;
            case 'p' : map = 0x6484; break;
            case 'q' : map = 0x44c3; break;
            case 'r' : map = 0x2400; break;
            case 's' : map = 0x08b2; break;
            case 't' : map = 0x6410; break;
            case 'u' : map = 0x2030; break;
            case 'v' : map = 0x2200; break;
            case 'w' : map = 0x2221; break;
            case 'x' : map = 0x0a05; break;
            case 'y' : map = 0x007a; break;
            case 'z' : map = 0x0294; break;
            default  : return 1;
          }
        }
        
        if((value >= 'A') && (value <= 'Z')){
        switch(value & 0x7f) {
           case 'A' : map = 0x64E2; break;
           case 'B' : map = 0x1FA  ; break;
           case 'C' : map = 0x6090; break;
           case 'D' : map = 0x1F8;  break;
           case 'E' : map = 0x6492; break;
           case 'F' : map = 0x6482; break;
           case 'G' : map = 0x60b2; break;
           case 'H' : map = 0x6462; break;
           case 'I' : map = 0x0198; break;
           case 'J' : map = 0x2070; break;
           case 'K' : map = 0x6405; break;
           case 'L' : map = 0x6010; break;
           case 'M' : map = 0x6864; break;
           case 'N' : map = 0x6861; break;
           case 'O' : map = 0x60f0; break;
           case 'P' : map = 0x64c2; break;
           case 'Q' : map = 0x60f1; break;
           case 'R' : map = 0x64c3; break;
           case 'S' : map = 0x08b2; break;
           case 'T' : map = 0x0188; break;
           case 'U' : map = 0x6070; break;
           case 'V' : map = 0x6204; break;
           case 'W' : map = 0x6261; break;
           case 'X' : map = 0x0a05; break;
           case 'Y' : map = 0x0904; break;
           case 'Z' : map = 0x0294; break;
            default  : return 1;
        }
        }
         if(value & 0x80) map |= CSEG_DP;
       } else return 1;

       for(i=0; i<16; i++) {
          lcd_seg(place++,map & 0x01);
          map >>= 1;
       }
      #endif // #ifdef LCD_4MUX_SOFTBAUGH
     #endif // #ifdef LCD_4MUX_7_5
    #endif // #ifdef LCD_STATIC_4_5
    return 0;
}

#ifdef LCD_4MUX_SOFTBAUGH
// email questions to: mahm0001@unf.edu
// place increments from LS(0) to MS(4,7,etc.)
char lcd_mini_char(char loc, char value) {
    unsigned char i;
    unsigned char map;
    unsigned char place = loc;

    // only 3 chars(digits)
    if(loc > 3) return 1;

    place = (loc+2) * 8;

    if(loc < 2) {
        // Right-hand two
        switch(value & 0x7f) {
            case ' ' : map = 0x00; break;
            case '-' : map = 0x02; break;
            case '0' : map = 0x7d; break;
            case '1' : map = 0x05; break;
            case '2' : map = 0x5b; break;
            case '3' : map = 0x1f; break;
            case '4' : map = 0x27; break;
            case '5' : map = 0x3e; break;
            case '6' : map = 0x7e; break;
            case '7' : map = 0x15; break;
            case '8' : map = 0x7f; break;
            case '9' : map = 0x3f; break;
            case 'l' : map = 0x68; break;
            case 'L' : map = 0x68; break;
            default  : return 1;
        }
    } else {
        // Left-hand two
        switch(value & 0x7f) {
            case ' ' : map = 0x00; break;
            case '-' : map = 0x20; break;
            case '0' : map = 0xd7; break;
            case '1' : map = 0x06; break;
            case '2' : map = 0xe3; break;
            case '3' : map = 0xa7; break;
            case '4' : map = 0x36; break;
            case '5' : map = 0xb5; break;
            case '6' : map = 0xf5; break;
            case '7' : map = 0x07; break;
            case '8' : map = 0xf7; break;
            case '9' : map = 0xb7; break;
            default  : return 1;
        }
    }
    i = 0;

    for(; i<8; i++) {
        lcd_seg(place++,map & 0x01);
        map >>= 1;
    }

    return 0;
}
#endif // #ifdef LCD_4MUX_SOFTBAUGH


// email questions to: mahm0001@unf.edu
char lcd_word(signed int value,char decimal) {
   // unsigned char signif = 0;

    lcd_all(0);
    //signif = 0;
    if(value < 0) {
        #ifdef LCD_STATIC_4_5
         lcd_seg(Sminus,1);
        #else
         #ifdef LCD_4MUX_SOFTBAUGH
          lcd_seg(SEG_MINUS,1);
         #endif
        #endif
        value *= -1;
    }

    #ifdef LCD_STATIC_4_5
     if(value >= 20000) {
        lcd_char(2,'0');
        lcd_char(1,'L');
        return 1;
     } else {
        lcd_char(3, (value/1000)%10 + '0');
        lcd_char(2, (value/100)%10 + '0');
        lcd_char(1, (value/10)%10 + '0');
        lcd_char(0, (value%10) + '0');
        lcd_seg(S_4,value >= 10000);
     }
    #else // #ifdef LCD_STATIC_4_5
     lcd_char(4, (value/10000) + '0');
     lcd_char(3, (value/1000)%10 + '0');
     lcd_char(2, (value/100)%10 + '0');
     lcd_char(1, (value/10)%10 + '0');
     lcd_char(0, (value%10) + '0');
    #endif

     switch(decimal) {
        case 0:  break;
        #ifdef LCD_4MUX_SOFTBAUGH
         case 1:  lcd_seg(CHAR_0*8 + CSEG_DP,1); break;
         case 2:  lcd_seg(CHAR_1*8 + CSEG_DP,1); break;
         case 3:  lcd_seg(CHAR_2*8 + CSEG_DP,1); break;
         case 4:  lcd_seg(CHAR_3*8 + CSEG_DP,1); break;
         case 5:  lcd_seg(CHAR_4*8 + CSEG_DP,1); break;
         case 6:  lcd_seg(CHAR_5*8 + CSEG_DP,1); break;
        #else
         case 1:  lcd_seg(S_DP3,1); break;
         case 2:  lcd_seg(S_DP2,1); break;
         case 3:  lcd_seg(S_DP1,1); break;
        #endif
        default: return 1;
     }

    return 0;
}

#ifdef LCD_4MUX_SOFTBAUGH
// email questions to: mahm0001@unf.edu
char lcd_mini_word(signed int value,char decimal) {
    unsigned char signif = 0;

    lcd_all(0);
     signif = 0;
    if(value < 0) {
        lcd_mini_char(3,'-');
        if(value <= -1000) {
            lcd_mini_char(2,'0');
            lcd_mini_char(1,'L');
            return 0;
        }
        value *= -1;
    } else {
        if(value >= 10000) {
            lcd_mini_char(2,'0');
            lcd_mini_char(1,'L');
            return 0;
        }
        lcd_mini_char(3, (value/1000)%10 + '0');
    }

    lcd_mini_char(2, (value/100)%10 + '0');
    lcd_mini_char(1, (value/10)%10 + '0');
    lcd_mini_char(0, (value%10) + '0');

    switch(decimal) {
        case 0:  break;
        case 1:  lcd_seg(N_0*8 + NSEG_RH_DP,1); break;
        case 2:  lcd_seg(N_2*8 + NSEG_LH_DP,1); break;
        case 3:  lcd_seg(N_3*8 + NSEG_LH_DP,1); break;
        case 4:  lcd_seg(N_1*8 + NSEG_RH_DP,1); break;
        default: return 1;
    }

    return 0;
}
#endif // #ifdef LCD_4MUX_SOFTBAUGH


// email questions to: mahm0001@unf.edu
void lcd_text(char *pStr) {
    char temp;
    #ifdef LCD_4_5
     signed char at_char = 4;
     const signed chars = 4;
    #else
     signed char at_char = 6;
     const signed chars = 6;
    #endif // #ifdef LCD_4_5

    for(; at_char >= 0; at_char--) {
        if((temp = pStr[chars-at_char]) == '\0') return;
        lcd_char(at_char,temp);
    }
}

// void lcd_scroll(char *pStr); function
void lcd_scroll(char *pStr) {
    signed char  position, end;
    char *pCurr,
    #ifdef LCD_4_5
         *pFirst = pStr-3;
    #else
         *pFirst = pStr-6;
    #endif

    for(; (pFirst < pStr) || (*pFirst != 0x0); pFirst++) {
        // update the display
    #ifdef LCD_4_5
        for(end = 0, position = 3, pCurr = pFirst; position != -1; position--) {
    #else
        for(end = 0, position = 6, pCurr = pFirst; position != -1; position--) {
    #endif
            if((pCurr < pStr) || end)
                lcd_char(position,' ');
            else if(*pCurr == 0x0) {
                end = 1;
                lcd_char(position,' ');
            } else
                lcd_char(position,*pCurr);
            pCurr++;
        }

        // wait some time so it's readable
        wait_ms(LCD_SCROLL_STEP_TIME);
    }
}

/*********************** 
* delay ms milliseconds 
***********************/ 
void wait_ms(int ms){ 
  int i; 
  for(i=ms;i>0;i--){ 
   dly1ms(); 
  } 
} 

/****************************************** 
* delay TC1MS clock cycles = 1 millisecond 
******************************************/ 
void dly1ms(void) { 
  int i=TC1MS; 
  while(i){ 
    i--; 
  } 
  return; 
} 
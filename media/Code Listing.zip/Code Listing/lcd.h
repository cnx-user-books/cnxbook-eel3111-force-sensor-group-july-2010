#ifndef __LCD_H
 #define __LCD_H
//******************************************************************************
//  MSP430F449 LCD interface
//
//  Description:
//    Numerical Direct Drive LCD interface
//    
//******************************************************************************

//#define LCD_STATIC_4_5
//******************************************************************************
//    
//Dig No:    4      3        2        1        0
//
//     <---  |    +-a-+    +---+    +---+    +---+
//           |    f   b C1 |   | C2 |   |    |   |
//       |   4    +-g-+ :  +---+ :  +---+    +---+
//      ---  |    e   c    |   |    |   |    |   |
//       |   | .  +-d-+ .  +---+ .  +---+ .  +---+
//            DP4      DP3      DP2      DP1
//    
//
//  Segment  0    1    2    3    4    5    6    7    8    9
//     x    3a   3b   3c   3d   3e   3f   3g   DP3  2a   2b
//    1x    2c   2d   2e   2f   2g   DP2  1a   1b   1c   1d
//    2x    1e   1f   1g   DP1  0a   0b   0c   0d   0e   0f
//    3x    0g   C2   C1    4   DP4   -    +  arrow 
//******************************************************************************

//#define LCD_4MUX_7_5
//******************************************************************************
//Dig No:    
//     7            6        5        4        3        2        1        0
//
//     |          +-a-+    +---+    +---+    +---+    +---+    +---+    +---+
//     b    |     f   b    |   |    |   |    |   |    |   |    |   |    |   |
//        -- --   +-g-+    +---+    +---+    +---+    +---+    +---+    +---+
//     c    |     e   c    |   |    |   |    |   |    |   |    |   |    |   |
//     |          +-d-+    +---+    +---+    +---+ .  +---+ .  +---+ .  +---+
//                --u--    -----    -----         DP3      DP2      DP1 -----
//    
//
//  Segment  0    1    2    3    4    5    6    7   
//     x    0a   0b   0d   0g   0c   0f   0u   0e   
//    1x    1a   1b   1d   1g   1c   1f   1p   1e   
//    2x    2a   2b   2d   2g   2c   2f   2p   2e   
//    3x    3a   3b   3d   3g   3c   3f   3p   3e   
//    4x    4a   4b   4d   4g   4c   4f   4u   4e   
//    5x    5a   5b   5d   5g   5c   5f   5u   5e   
//    6x    6a   6b   6d   6g   6c   6f   6u   6e   
//    7x    7c        +    7b 
//******************************************************************************

#define LCD_4MUX_SOFTBAUGH
//******************************************************************************
//Dig No:    
//     7            6        5        4        3        2        1        0
//
//     |          +-a-+    +---+    +---+    +---+    +---+    +---+    +---+
//     b    |     f   b    |   |    |   |    |   |    |   |    |   |    |   |
//        -- --   +-g-+    +---+    +---+    +---+    +---+    +---+    +---+
//     c    |     e   c    |   |    |   |    |   |    |   |    |   |    |   |
//     |          +-d-+    +---+    +---+    +---+ .  +---+ .  +---+ .  +---+
//                --u--    -----    -----         DP3      DP2      DP1 -----
//    
//
//  Segment  0    1    2    3    4    5    6    7   
//     x    0a   0b   0d   0g   0c   0f   0u   0e   
//    1x    1a   1b   1d   1g   1c   1f   1p   1e   
//    2x    2a   2b   2d   2g   2c   2f   2p   2e   
//    3x    3a   3b   3d   3g   3c   3f   3p   3e   
//    4x    4a   4b   4d   4g   4c   4f   4u   4e   
//    5x    5a   5b   5d   5g   5c   5f   5u   5e   
//    6x    6a   6b   6d   6g   6c   6f   6u   6e   
//    7x    7c        +    7b 
//******************************************************************************

void setupLCD(void);
void lcd_all(char on);
char lcd_seg(char segment, char on);
char lcd_seg_toggle(char segment);
char lcd_char(char place, char value);
#ifdef LCD_4MUX_SOFTBAUGH
 char lcd_mini_char(char place, char value);
 char lcd_mini_word(signed int value,char decimal);
#endif
char lcd_word(signed int value,char decimal);
void lcd_text(char *pStr);
void lcd_scroll(char *pStr);

#ifdef LCD_STATIC_4_5
 #define S_C2     31
 #define S_C1     32
 #define S_DP1     7
 #define S_DP2    15
 #define S_DP3    23
 #define S_4      33
 #define S_DP4    34
 #define Sminus   35
 #define Splus    36
 #define S_ARROW  37
 #define SEG_A     0
 #define SEG_B     1
 #define SEG_C     2
 #define SEG_D     3
 #define SEG_E     4
 #define SEG_F     5
 #define SEG_G     6
 #define SEG_DP    7

 #define SR_A     0
 #define SR_B     0
 #define SR_C     1
 #define SR_D     1
 #define SR_E     2
 #define SR_F     2
 #define SR_G     3
 #define SR_DP    3

 #define DOT_ON  0x80
 #define DOT_OFF 0x00
#endif // #ifdef LCD_STATIC_4_5

#ifdef LCD_4MUX_7_5
 #define SEG_A    0
 #define SEG_B    1
 #define SEG_D    2
 #define SEG_G    3
 #define SEG_C    4
 #define SEG_F    5
 #define SEG_ALT  6
 #define SEG_E    7
 #define SEG_7C   0
 #define SEG_PLUS 2
 #define SEG_7B   3

 #define CHAR_0   0<<3
 #define CHAR_1   1<<3
 #define CHAR_2   2<<3
 #define CHAR_3   3<<3
 #define CHAR_4   4<<3
 #define CHAR_5   5<<3
 #define CHAR_6   6<<3
 #define CHAR_7   7<<3
#endif // #ifdef LCD_4MUX_7_5

#ifdef LCD_4MUX_SOFTBAUGH
 #define BSEG_L     3
 #define BSEG_0     2
 #define BSEG_1     1
 #define BSEG_2     0
 #define BSEG_3     4
 #define BSEG_4     5
 #define BSEG_5     6
 #define BSEG_6     7
 #define BSEG_7     11
 #define BSEG_8     10
 #define BSEG_9     9 
 #define BSEG_R     8

 #define ARROW_L     12
 #define ARROW_R     13
 #define ARROW_U     14
 #define ARROW_D     15

 // left-hand two digits
 #define NSEG_LH_A     0
 #define NSEG_LH_B     1
 #define NSEG_LH_C     2
 #define NSEG_LH_DP    3
 #define NSEG_LH_F     4
 #define NSEG_LH_G     5
 #define NSEG_LH_E     6
 #define NSEG_LH_D     7
 // right-hand two digits
 #define NSEG_RH_B     0
 #define NSEG_RH_G     1
 #define NSEG_RH_C     2
 #define NSEG_RH_D     3
 #define NSEG_RH_A     4
 #define NSEG_RH_F     5
 #define NSEG_RH_E     6
 #define NSEG_RH_DP    7

 #define CSEG_A     7
 #define CSEG_B     6
 #define CSEG_C     5
 #define CSEG_D     4
 #define CSEG_E     13
 #define CSEG_F     14
 #define CSEG_G     10
 #define CSEG_H     11
 #define CSEG_J     3
 #define CSEG_K     2
 #define CSEG_M     1
 #define CSEG_N     0
 #define CSEG_P     8
 #define CSEG_Q     9
 #define CSEG_DP    12
 #define CSEG_SB    15
 #define CSEG_COLON 15

 #define BAR_L    0
 #define BAR_H    1
 #define ARROW    1
 #define N_0      2
 #define N_1      3
 #define N_2      4
 #define N_3      5
 #define CHAR_0   6
 #define CHAR_0H  7
 #define CHAR_1   8
 #define CHAR_1H  9
 #define CHAR_2   10
 #define CHAR_2H  11
 #define CHAR_3   12
 #define CHAR_3H  13
 #define CHAR_4   14
 #define CHAR_4H  15
 #define CHAR_5   16
 #define CHAR_5H  17
 #define CHAR_6   18
 #define CHAR_6H  19
 
 #define SEG_MINUS 156
 #define SEG_PLUS 159
#endif // #ifdef LCD_4MUX_SOFTBAUGH

#define LCD_SCROLL_STEP_TIME 300


#endif // #ifndef __LCD_H
